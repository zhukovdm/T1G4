query-1-1.jq
Select all routes served by train and having length over 20 km.

query-1-2.jq
Get name, email and phone of an agency which owns bus that rides
a connection with more than two stops, avoid duplicates.

query-1-3.jq
Select all Czech names of stations with which starts a route that
belongs to connection which is ridden by a train. Names should start
with letter "H".

query-2-1.jq
Find license plate numbers of all buses produced by Tatra with
at least 20 units of consumption.

query-2-2.jq
Find German producers, which had produced vehicles with purchase
price greater than 150000 units.
